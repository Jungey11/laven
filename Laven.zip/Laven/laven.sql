-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2023 at 08:55 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laven`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_products`
--

CREATE TABLE `cart_products` (
  `cartID` int(11) NOT NULL,
  `productID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `productCategory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`productCategory`) VALUES
('Hoodies/Sweatshirts'),
('Jackets'),
('Jeans/Pants'),
('Jersey'),
('Joggers'),
('Men'),
('Shoes'),
('Shorts'),
('Skirts'),
('Sports Shoes'),
('Sports Wear'),
('Sweaters'),
('T-Shirt'),
('Tops'),
('Women');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productPrice` double NOT NULL,
  `productStock` int(11) NOT NULL,
  `productBrand` varchar(255) NOT NULL,
  `productCategory` varchar(255) NOT NULL,
  `productStars` float NOT NULL DEFAULT 0,
  `productDescription` varchar(500) DEFAULT NULL,
  `productImage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='stores product information';

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `productName`, `productPrice`, `productStock`, `productBrand`, `productCategory`, `productStars`, `productDescription`, `productImage`) VALUES
(15, 'SDMN Varsity T-Shirt Stone', 5200, 30, 'Sidemen', 'T-Shirt', 0, 'Screen print design. XIX woven tag. Oversized/drop shoulder style fit.', 'OffWhite T-Shirt.png'),
(16, 'Jordan Why Not .6 Basketball Shoes', 18300, 10, 'Jordan', 'Sports Shoes', 0, 'Russell Westbrook\'s 6th signature shoe isyou guessed itall about speed. Added security comes from the interior bootie that keeps you strapped in as you jet across the court.', 'Why Not.png'),
(17, 'XIX Nitro Shell Jacket', 11900, 15, 'Sidemen', 'Jackets', 0, 'XIX Nitro patch. Pongee silk lining.', 'Black Jacket.png'),
(18, 'SDMN Varsity Hoodie Forest Green', 10200, 5, 'Sidemen', 'Hoodies/Sweatshirts', 0, 'SDMN varsity embroidery appliqué design. XIX woven tag. Oversized/drop shoulder style fit.', 'Green Hoodie.png'),
(19, 'Corset-style Top', 2350, 30, 'H&M', 'Sweaters', 0, 'Short bandeau corset top in woven fabric. Sweetheart neckline, shaped, lined cups, and hook-and-eye fasteners at front. Gently rounded hem at front.', 'Corset-style Top.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `ratingID` int(11) NOT NULL,
  `productStars` float DEFAULT 0,
  `productComment` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `productID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='stores product ratings';

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`ratingID`, `productStars`, `productComment`, `username`, `productID`) VALUES
(4, 4, 'Good Quality', 'easymoneysniper', 18);

-- --------------------------------------------------------

--
-- Table structure for table `register_user`
--

CREATE TABLE `register_user` (
  `username` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(15) NOT NULL,
  `image` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='stores user registration data ';

--
-- Dumping data for table `register_user`
--

INSERT INTO `register_user` (`username`, `firstname`, `lastname`, `password`, `role`, `image`) VALUES
('admin', 'Yashil', 'Singh', 'PKCY06+AaoTBnYf0HiV9B+JzLxZsb1DRYsBxD/XCBzVSCzczI9Pfmf2RoBg+T1UdHw==', 'admin', 'cypher.png'),
('antDavis03', 'Anthony', 'Davis', 'hUEBvW7PcjhJUJLH46AS+e8SnQVuFxuCKUyJ2P9ALnTLldVV8M0PSPOxFcQBCAw=', 'user', 'AD2.jpeg'),
('drose1', 'Kyrie', 'Singh', 'njrpyxkdjIIyIG2QZsvP/O0waXLBRwfinWabyYzNu0Csl26Fxlc6xPojlIlCg7w=', 'user', 'derrick-rose.jpg'),
('easymoneysniper', 'Kevin', 'Durant', 'rH584NlFyG+QoAbTjy7p7piZNHGRj6jzTEcwL+WGxQnpjH2QR3dItHYUYF67EvA=', 'user', 'durant.jpg'),
('king', 'LeKing', 'James', 'Vcv3GBcJG5vW+FHgd7mfEwjaxc6SeAD9LuR6z99dBr2VI5mH0GLegzGzP6DZWvE=', 'user', 'lebron.png'),
('thebread13', 'James', 'Harder', 'kkpQuwy20+KvtX6Z7N8s6ZdWL3qM3KPBa9O+JyuRNKy45XwPUvOo2M2FHvqRIyA=', 'user', 'harden.jpg'),
('uncDrew', 'Kai', 'Irving', '7fABlKfONdB7u81NXxYEn1m3zJh2PYY3Vb0xfDnpu44IOJqBBS2CMUZT/S4188A=', 'user', 'kyrie.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `cart_products`
--
ALTER TABLE `cart_products`
  ADD KEY `cartID` (`cartID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`productCategory`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `productCategory` (`productCategory`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`ratingID`),
  ADD KEY `productID` (`productID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `register_user`
--
ALTER TABLE `register_user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `ratingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`username`) REFERENCES `register_user` (`username`);

--
-- Constraints for table `cart_products`
--
ALTER TABLE `cart_products`
  ADD CONSTRAINT `cart_products_ibfk_1` FOREIGN KEY (`cartID`) REFERENCES `cart` (`cartID`),
  ADD CONSTRAINT `cart_products_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`productCategory`) REFERENCES `categories` (`productCategory`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`username`) REFERENCES `register_user` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
